# stellar-yszy
恒星播放器的影视资源采集网插件